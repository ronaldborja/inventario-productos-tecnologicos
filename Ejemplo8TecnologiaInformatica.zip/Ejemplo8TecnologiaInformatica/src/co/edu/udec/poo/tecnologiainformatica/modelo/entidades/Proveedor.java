package co.edu.udec.poo.tecnologiainformatica.modelo.entidades;

import java.io.Serializable;
import java.util.*;

public class Proveedor implements Serializable  {
    // Atributos. 
    private String idProveedor; 
    private String nombreProveedor; 
    private String nifProveedor; 
    private String direccionProveedor; 
    private String fechaCompra;
    private int numProductos; 
    // Ref a obj
    private ArrayList<Producto> listaProductos; 
    
    // Constructores. 
    public Proveedor() {
        
    }

    public Proveedor(String idProveedor, String nombreProveedor, String nifProveedor, String direccionProveedor, String fechaCompra) {
        this.idProveedor = idProveedor;
        this.nombreProveedor = nombreProveedor;
        this.nifProveedor = nifProveedor;
        this.direccionProveedor = direccionProveedor;
        this.fechaCompra = fechaCompra;
        this.listaProductos = listaProductos;
    }

    public String getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(String idProveedor) {
        this.idProveedor = idProveedor;
    }

    public String getNombreProveedor() {
        return nombreProveedor;
    }

    public void setNombreProveedor(String nombreProveedor) {
        this.nombreProveedor = nombreProveedor;
    }

    public String getNifProveedor() {
        return nifProveedor;
    }

    public void setNifProveedor(String nifProveedor) {
        this.nifProveedor = nifProveedor;
    }

    public String getDireccionProveedor() {
        return direccionProveedor;
    }

    public void setDireccionProveedor(String direccionProveedor) {
        this.direccionProveedor = direccionProveedor;
    }

    public String getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(String fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public ArrayList<Producto> getListaProductos() {
        return listaProductos;
    }

    public void setListaProductos(ArrayList<Producto> listaProductos) {
        this.listaProductos = listaProductos;
    }
    
    public int numProductos() { 
        return listaProductos.size(); 
    }

    public int getNumProductos() {
        return numProductos;
    }

    public void setNumProductos(int numProductos) {
        this.numProductos = numProductos;
    }
    
    
}
