
package co.edu.udec.poo.tecnologiainformatica.modelo.crud;

import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.Alquiler;
import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.Producto;
import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.Proveedor;
import java.io.Serializable;
import java.util.*;


public class AlquilerCrud implements Serializable {
    public AlquilerCrud() {
        
    }
    
    // Lista para almacenar los movimientos alquiler. 
    private static HashMap<String,Alquiler> alquilerBD; 
    
    // Métodos CRUD.  
    public void agregar(Alquiler alquiler) {
        try { 
            if (alquilerBD == null) {
                alquilerBD = new HashMap<>();
            }
            alquilerBD.put(alquiler.getIdAlquiler(), alquiler);
            System.out.println("Alquiler guardado con exito! \n");
            
        }catch (Exception ex) {
            if (alquilerBD.containsKey(alquiler.getIdAlquiler())) {
                System.out.println("El alquiler ya está registrado!\n");
            }
        } 
    }
    
    public void buscar(String idAlquiler) {
        if (alquilerBD == null || alquilerBD.isEmpty()){
            System.out.println("No existen alquileres registrados en la BD.\n");    
        }
        
        try {
            if (alquilerBD.containsKey(idAlquiler)) {
                System.out.println("Los datos del alquiler buscado son: ");
                System.out.println("Precio Hora: " + alquilerBD.get(idAlquiler).getPrecioHora());
                System.out.println("ID: "+ alquilerBD.get(idAlquiler).getIdAlquiler());
                System.out.println("Fecha: " + alquilerBD.get(idAlquiler).getFechaAlquiler());
                System.out.println("Producto: " + alquilerBD.get(idAlquiler).getProducto().getNombreProducto()); 
                // Imprimimos la lista proveedores. 

            }
        }catch(Exception ex) {
            System.out.println("El Alquiler no existe en la BD!\n");
        }
    }   
    
    public void editar(Alquiler al) {
        try{
            // Tomamos los del producto nuevo.  
            String idAlquiler = al.getIdAlquiler(); 
            double precioHora = al.getPrecioHora();
            String fechaAlquiler = al.getFechaAlquiler(); 
            Producto p = al.getProducto(); 
            
            // Verificamos que este en el diccionario. 
            if (alquilerBD.containsKey(idAlquiler)) {
                //Pasamos los nuevos datos. 
                Alquiler nuevoAlq = alquilerBD.get(idAlquiler);
                nuevoAlq.setFechaAlquiler(fechaAlquiler);
                nuevoAlq.setPrecioHora(precioHora);
                nuevoAlq.setProducto(p);
                System.out.println("El Alquiler ha sido editado con exito!\n");
            }
            
            else {
                System.out.println("El Alquiler no se encontró en la BD!\n");
            }
            
        } catch (Exception ex) {
            System.out.println("Se encontró un error al editar el alquiler...");
        }  
    }

    public void eliminar(String idAlquiler) {
        try {
            if (alquilerBD.containsKey(idAlquiler)) {
                alquilerBD.remove(idAlquiler); 
                System.out.println("Alquiler eiminado con exito!\n");
            }
            
            else { 
                System.out.println("El Alquiler no fue encontrado en la BD!");
            }
        } catch(Exception ex){
            System.out.println("Se encontró un error al eliminar el alquiler...");
        }
    }
    
    public void listarTodo() {
        // Recorremos el HashMap
        try{
            for (Alquiler alquiler: alquilerBD.values()){
                System.out.println("\n\t.:Listado de alquileres:.");
                System.out.println("Id: " + alquiler.getIdAlquiler());
                System.out.println("Producto: " + alquiler.getProducto().getNombreProducto());
                System.out.println("Precio Hora: " + alquiler.getPrecioHora());
                System.out.println("Fecha Alquiler: " + alquiler.getFechaAlquiler());
                System.out.println("Total Alquilados: " + alquiler.getTotalAlquilados());
                System.out.println("");
            }
        } catch(Exception ex) {
            if (alquilerBD == null || alquilerBD.isEmpty()) {
                System.out.println("No hay alquileres registrados en la BD!");
            }
        }
    }   
    
    public Integer contar() {
        System.out.println("\nEl numero de alquileres registrados es de: " + alquilerBD.size());
        return alquilerBD.size(); 
    }
    
    //Getters y Setters.

    public static HashMap<String, Alquiler> getAlquilerBD() {
        return alquilerBD;
    }

    public static void setAlquilerBD(HashMap<String, Alquiler> alquilerBD) {
        AlquilerCrud.alquilerBD = alquilerBD;
    }
    
    
}
