package co.edu.udec.poo.tecnologiainformatica.modelo.crud;
import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.EmpresaFabricante;
import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.Producto;
import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.Proveedor;
import java.io.Serializable;
import java.util.*;

public class ProveedorCrud implements Serializable {
    
    public ProveedorCrud() {
    }
    
   //Creamos el HashMap con objetos tipo proveedor. 
   private static HashMap<String, Proveedor> proveedoresBD;
   
   //Métodos CRUD. 
    public void agregar(Proveedor proveedor) {
        try { 
            if (proveedoresBD == null) {
                proveedoresBD = new HashMap<>();
            }
            proveedoresBD.put(proveedor.getIdProveedor(), proveedor);
            System.out.println("Proveedor guardado con exito! ");
            
        }catch (Exception ex) {
            if (proveedoresBD.containsKey(proveedor.getIdProveedor())) {
                System.out.println("El proveedor ya está registrado!");
            }
        }
    }
    
    public void buscar(String codigoProvedor) { 
        if (proveedoresBD == null || proveedoresBD.isEmpty()){
            System.out.println("\nNo existen proveedores registrados en la BD.");    
        }
        
        try {
            if (proveedoresBD.containsKey(codigoProvedor)) {
                System.out.println("Los datos del provedor buscado son: ");
                System.out.println("ID: "+ proveedoresBD.get(codigoProvedor).getIdProveedor());
                System.out.println("Nombre: " + proveedoresBD.get(codigoProvedor).getNombreProveedor());
                System.out.println("NIF: " + proveedoresBD.get(codigoProvedor).getNifProveedor());
                System.out.println("Dirección: " + proveedoresBD.get(codigoProvedor).getDireccionProveedor());
                System.out.println("Fecha Compra: "+ proveedoresBD.get(codigoProvedor).getFechaCompra());
                System.out.println("Num Productos: " + proveedoresBD.get(codigoProvedor).numProductos());          
            }
            
            else {
               System.out.println("El proveedor no existe en la BD!"); 
            }
        }catch(Exception ex) {
            System.out.println("\nSe encontró un error al buscar el proveedor...!");
        }
    }
    
    public void editar(Proveedor p) {
        try{
            // Tomamos los del producto nuevo.  
            String idProveedor = p.getIdProveedor(); 
            String nombreProveedor = p.getNombreProveedor();
            String NIF = p.getNifProveedor(); 
            String direccion = p.getDireccionProveedor(); 
            String fechaCompra = p.getFechaCompra(); 
            
            // Verificamos que este en el diccionario. 
            if (proveedoresBD.containsKey(idProveedor)) {
                //Pasamos los nuevos datos. 
                Proveedor provNuevo = proveedoresBD.get(idProveedor);
                provNuevo.setIdProveedor(idProveedor);
                provNuevo.setNombreProveedor(nombreProveedor);
                provNuevo.setNifProveedor(NIF);
                provNuevo.setDireccionProveedor(direccion);
                provNuevo.setFechaCompra(fechaCompra);
                
                System.out.println("\nEl proveedor ha sido editado con exito!");
            }
            
            else {
              System.out.println("\nEl proveedor no se encontró en la BD!");  
            }
            
        } catch (Exception ex) {
            System.out.println("\n Se encontró un error al registrar el proveedor...");
        }  
    }
    
    public void eliminar(String codigoProveedor) {
        try {
            if (proveedoresBD.containsKey(codigoProveedor)) {
                proveedoresBD.remove(codigoProveedor); 
                System.out.println("\nProveedor eiminado con exito!");
            }
            else {
                System.out.println("\nEl proveedor no fue encontrado en la BD!");
            }
        } catch(Exception ex){
            System.out.println("\nSe encontró un error al eliminar el producto");
        }
    }
    
    public void listarTodo() {
        // Recorremos el HashMap
        try{
            for (Proveedor proveedor: proveedoresBD.values()){
                System.out.println("\n\t.:Listado de proveedores:.");
                System.out.println("Id proveedor: " + proveedor.getIdProveedor());
                System.out.println("Nombre: " + proveedor.getNombreProveedor());
                System.out.println("NIF: " + proveedor.getNifProveedor());
                System.out.println("Dirección: " + proveedor.getDireccionProveedor());
                System.out.println("Fecha Compra: " + proveedor.getFechaCompra());
                System.out.println("Num Productos: "+ proveedor.numProductos());
                System.out.println("");
            }
        } catch(Exception ex) {
            if (proveedoresBD == null || proveedoresBD.isEmpty()) {
                System.out.println("\nNo hay proveedores registrados en la BD!");
            }
        }
    }
    
    public Integer contar() {
        System.out.println("\nEl numero de proveedores registrados es de: " + proveedoresBD.size());
        return proveedoresBD.size(); 
    }
    
    // Getters y Setters. 

    public static HashMap<String, Proveedor> getProveedoresBD() {
        return proveedoresBD;
    }

    public static void setProveedoresBD(HashMap<String, Proveedor> proveedoresBD) {
        ProveedorCrud.proveedoresBD = proveedoresBD;
    }
}
