package co.edu.udec.poo.tecnologiainformatica.modelo.crud;

import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.Producto;
import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.Venta;
import java.io.Serializable;
import java.util.*;

public class VentaCrud implements Serializable {
    
    public VentaCrud(){
    }
    
    //Creamos un HashMap para almacenar las ventas. 
    private static HashMap<String,Venta> ventasBD;
    
    //Métodos CRUD. 
    public void agregar(Venta venta) {
        try { 
            if (ventasBD == null) {
                ventasBD = new HashMap<>();
            }
            ventasBD.put(venta.getIdVenta(), venta);
            System.out.println("Venta guardada con exito! ");
            
        }catch (Exception ex) {
            if (ventasBD.containsKey(venta.getIdVenta())) {
                System.out.println("La venta ha sido registrada previamente!");
            }
        }  
    }
    
    public void buscar(String idVenta) {
        //1. Usar el codigo que recibe como parametros para retornar los datos del producto. 
        //2. Si no lo encuentra lanzar una excepción. 
        if (ventasBD == null || ventasBD.isEmpty()){
            System.out.println("\nNo existen ventas registradas en la BD.");    
        }
        
        try {
            if (ventasBD.containsKey(idVenta)) {
                System.out.println("Los datos de la venta buscada son: ");
                System.out.println("Producto: " + ventasBD.get(idVenta).getProducto().getNombreProducto());
                System.out.println("ID Venta: "+ ventasBD.get(idVenta).getIdVenta());
                System.out.println("Fecha Venta: " + ventasBD.get(idVenta).getFechaVenta());
                System.out.println("No. Productos Vendidos: " + ventasBD.get(idVenta).getNumProductosVendidos());   
            }
            
            else {
                System.out.println("\nLa venta no existe en la BD!");
            }
        }catch(Exception ex) {
            System.out.println("\nSe encontró un error al buscar la venta...");
        }
    }
    
    public void editar(Venta v) {
        try{
            // Tomamos los del producto nuevo.  
            String idVenta = v.getIdVenta(); 
            String fechaVentas = v.getFechaVenta();
            int numProductos = v.getNumProductosVendidos(); 
            Producto p = v.getProducto(); 
            
            // Verificamos que este en el diccionario. 
            if (ventasBD.containsKey(idVenta)) {
                //Pasamos los nuevos datos. 
                Venta vNueva = ventasBD.get(idVenta);
                vNueva.setFechaVenta(fechaVentas);
                vNueva.setNumProductosVendidos(numProductos);
                vNueva.setProducto(p);
                System.out.println("\nLa venta ha sido modificada con exito!");
            }
            else {
                System.out.println("\nLa venta no se encontró en la BD!");
            }
            
        } catch (Exception ex) {
            System.out.println("\nSe encontró un error al editar la venta...");
        }  
    }
    
    public void eliminar(String idVenta) {
        try {
            if (ventasBD.containsKey(idVenta)) {
                ventasBD.remove(idVenta); 
                System.out.println("Venta eliminada con exito!\n");
            }
            
            else { 
                System.out.println("La venta no fue encontrada en la BD!");
            }
        } catch(Exception ex){
            System.out.println("Se encontró un error al eliminar la venta...");
        }
    }
    
    public void listarTodo() {
        // Recorremos el HashMap
        try{
            for (Venta venta: ventasBD.values()){
                System.out.println("\n\t.:Listado de ventas:.");
                System.out.println("IdVenta: " + venta.getIdVenta());
                System.out.println("Producto: " + venta.getProducto().getNombreProducto());
                System.out.println("Fecha venta: " + venta.getFechaVenta());
                System.out.println("Cantidad: " + venta.getNumProductosVendidos());
                System.out.println(" ");
            }
        } catch(Exception ex) {
            if (ventasBD == null || ventasBD.isEmpty()) {
                System.out.println("No hay ventas registrados en la BD!");
            }
        }
    }
    
    public Integer contar() {
        System.out.println("\nEl numero de ventas registrados es de: " + ventasBD.size());
        return ventasBD.size(); 
    }
    
    // Getters y Setters 

    public static HashMap<String, Venta> getVentasBD() {
        return ventasBD;
    }

    public static void setVentasBD(HashMap<String, Venta> ventasBD) {
        VentaCrud.ventasBD = ventasBD;
    }
    
    
}
