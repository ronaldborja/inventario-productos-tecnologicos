package co.edu.udec.poo.tecnologiainformatica.modelo.entidades;

import java.io.Serializable;
import java.util.*;

public class EmpresaFabricante implements Serializable {
    // Atributos de una empresaFabricante. 
    private String idEmpresa; 
    private String nombreEmpresa;
    private String direccionEmpresa;
    private int numEmpleados; 
    private double precioSoporteTecnico; 
    private String productoFabricado; 
    
    //Atributos tip ref a obj. 
    private ArrayList<Producto> productosAT; 
    
    // Constructores. 
    public EmpresaFabricante(){
        
    }

    public EmpresaFabricante(String idEmpresa, String nombreEmpresa, String direccionEmpresa, int numEmpleados, double precioSoporteTecnico) {
        this.idEmpresa = idEmpresa;
        this.nombreEmpresa = nombreEmpresa;
        this.direccionEmpresa = direccionEmpresa;
        this.numEmpleados = numEmpleados; 
        this.precioSoporteTecnico = precioSoporteTecnico;
        
    }
    
    // Getters & Setters. 
    public String getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(String idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public String getDireccionEmpresa() {
        return direccionEmpresa;
    }

    public void setDireccionEmpresa(String direccionEmpresa) {
        this.direccionEmpresa = direccionEmpresa;
    }

    public double getPrecioSoporteTecnico() {
        return precioSoporteTecnico;
    }

    public void setPrecioSoporteTecnico(double precioSoporteTecnico) {
        this.precioSoporteTecnico = precioSoporteTecnico;
    }

    public ArrayList<Producto> getProductosAT() {
        return productosAT;
    }

    public void setProductosAT(ArrayList<Producto> productosAT) {
        this.productosAT = productosAT;
    }

    public int getNumEmpleados() {
        return numEmpleados;
    }

    public void setNumEmpleados(int numEmpleados) {
        this.numEmpleados = numEmpleados;
    }

    public String getProductoFabricado() {
        return productoFabricado;
    }

    public void setProductoFabricado(String productoFabricado) {
        this.productoFabricado = productoFabricado;
    }
    
    
    
    
}
