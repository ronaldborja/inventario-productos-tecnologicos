package co.edu.udec.poo.tecnologiainformatica.modelo.entidades;

import java.io.Serializable;
import java.util.*;

public class Alquiler implements Serializable {
    // Atributos de la clase Alquiler.
    private String idAlquiler; 
    private double precioHora; 
    private String fechaAlquiler; 
    private int totalAlquilados;
    private String productoAlquilado; 
    
    // Atributos tipo ref a objetos. 
    private Producto producto;
    
    // Constructores. 
    public Alquiler(){ 
        
    }

    public Alquiler(String idAlquiler, double precioHora, String fechaAlquiler, int totalAlquilados, Producto producto) {
        this.idAlquiler = idAlquiler;
        this.precioHora = precioHora;
        this.fechaAlquiler = fechaAlquiler;
        this.totalAlquilados = totalAlquilados;
        this.producto = producto;
    }

    public String getIdAlquiler() {
        return idAlquiler;
    }

    public void setIdAlquiler(String idAlquiler) {
        this.idAlquiler = idAlquiler;
    }

    public double getPrecioHora() {
        return precioHora;
    }

    public void setPrecioHora(double precioHora) {
        this.precioHora = precioHora;
    }

    public String getFechaAlquiler() {
        return fechaAlquiler;
    }

    public void setFechaAlquiler(String fechaAlquiler) {
        this.fechaAlquiler = fechaAlquiler;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public int getTotalAlquilados() {
        return totalAlquilados;
    }

    public void setTotalAlquilados(int totalAlquilados) {
        this.totalAlquilados = totalAlquilados;
    }

    public String getProductoAlquilado() {
        return productoAlquilado;
    }

    public void setProductoAlquilado(String productoAlquilado) {
        this.productoAlquilado = productoAlquilado;
    }
    
    
    
}
