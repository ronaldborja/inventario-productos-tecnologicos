package co.edu.udec.poo.tecnologiainformatica.modelo.crud;

import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.EmpresaFabricante;
import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.Producto;
import java.io.Serializable;
import java.util.*;

public class ProductoCrud implements Serializable  {
    
    // Creamos un HashMap   
    private static HashMap<String, Producto> productosBD; 
    
    // Constructor por defecto 
    public ProductoCrud(){ 
    }
    
    //Métodos CRUD. 
    public void agregar(Producto p) {
        // Caracteristicas. 
        //1. Agregar en la lista el objeto que recibe como parametro de entrada. 
        //2. Si ha sido guardado previamente, lanzar excepción con mensaje informativo. 
        try {
            if (productosBD == null) {
            productosBD = new HashMap<>();
            }
            
            if (productosBD.containsKey(p.getCodigoProducto())) { 
                System.out.println("El producto ya está registrado!");
                return; 
            }
            
            productosBD.put(p.getCodigoProducto(), p);
            System.out.println("Producto guardado con exito!");
            
        }catch (Exception ex) {
                System.out.println("Se encontró un error al registrar el producto...");
        }
    }
    
    public void buscar(String codigoProducto) {
        //1. Usar el codigo que recibe como parametros para retornar los datos del producto. 
        //2. Si no lo encuentra lanzar una excepción. 
        if (productosBD == null || productosBD.isEmpty()){
            System.out.println("\nNo existen productos registrados en la BD.");    
        }
        
        try {
            if (productosBD.containsKey(codigoProducto)) {
                System.out.println("Los datos del producto buscado son: ");
                System.out.println("Nombre: "+ productosBD.get(codigoProducto).getNombreProducto());
                System.out.println("Codigo: " + productosBD.get(codigoProducto).getCodigoProducto());
                System.out.println("Modelo: " + productosBD.get(codigoProducto).getModeloProducto());
                System.out.println("Precio: " + productosBD.get(codigoProducto).getPrecioProducto());
                System.out.println("Disponible: "+ productosBD.get(codigoProducto).getCantidadDisponible());
                System.out.println("Mas Información: " + productosBD.get(codigoProducto).getMasInformacion());
                System.out.println("Pais de origen: " + productosBD.get(codigoProducto).getPaisOrigen());
                System.out.println("Fecha de fabricación: " + productosBD.get(codigoProducto).getFechaFabricacion());
                System.out.println("Empresa Fabricante: " + productosBD.get(codigoProducto).getEmpresaFabricante());
            }
            
            else {
                System.out.println("\nEl producto no existe en la BD!");
            }
            
        }catch(Exception ex) {
            System.out.println("\nSe encontró un error al agregar el producto...");
        }
    }
        
    public void editar(Producto p) {   
        //Cambiar en la lista si existe el objeto que recibe como parametro de entrada. 
        //Si no existe, el método debe mandar una excepción con un mensaje informativo. 
        try{
            // Tomamos los del producto nuevo.  
            String codigoProducto = p.getCodigoProducto(); 
            String modeloProducto = p.getModeloProducto(); 
            double precioProducto = p.getPrecioProducto() ;
            int cantidadDisponible = p.getCantidadDisponible() ;
            String masInformacion = p.getMasInformacion();
            String paisOrigen = p.getPaisOrigen();
            String fechaFabricacion = p.getFechaFabricacion();
            EmpresaFabricante empresaFabricante = p.getEmpresaFabricante();
            
            // Verificamos que este en el diccionario. 
            if (productosBD.containsKey(codigoProducto)) {
                //Pasamos los nuevos datos. 
                Producto pNuevo = productosBD.get(codigoProducto);
                pNuevo.setCodigoProducto(codigoProducto);
                pNuevo.setModeloProducto(modeloProducto);
                pNuevo.setPrecioProducto(precioProducto);
                pNuevo.setCantidadDisponible(cantidadDisponible);
                pNuevo.setMasInformacion(masInformacion);
                pNuevo.setPaisOrigen(paisOrigen);
                pNuevo.setFechaFabricacion(fechaFabricacion);
                pNuevo.setEmpresaFabricante(empresaFabricante);
                System.out.println("\nEl producto ha sido editado con exito!");
            }
            
            else {
                System.out.println("\nEl producto no se encontró en la BD!");
            }
            
        } catch (Exception ex) {
            System.out.println("\nSe encontró un error al editar el producto...!");
        }  
    }
     
    public void eliminar(String codigoProducto) {
        try {
            if (productosBD.containsKey(codigoProducto)) {
                productosBD.remove(codigoProducto); 
                System.out.println("\nProducto eiminado con exito!");
            }
            else {
                System.out.println("\nEl producto no fue encontrado en la BD!");
            }
        } catch(Exception ex){
            System.out.println("\nSe encontró un error al eliminar el producto...!");
        }
    }
    
    public void listarTodo() {
        // Recorremos el HashMap
        try{
            System.out.println("\n\t.:Listado de productos:.");
            for (Producto producto: productosBD.values()){
                System.out.println("Nombre: " + producto.getNombreProducto());
                System.out.println("Codigo: " + producto.getCodigoProducto());
                System.out.println("Modelo: " + producto.getModeloProducto());
                System.out.println("Precio: " + producto.getPrecioProducto());
                System.out.println("Cantidad Disp: " + producto.getCantidadDisponible());
                System.out.println(" ");
            }
        } catch(Exception ex) {
            if (productosBD == null || productosBD.isEmpty()) {
                System.out.println("No hay productos registrados en la BD!");
            }
        }
    }
    
    public Integer contar() {
        System.out.println("\nEl numero de productos registrados es de: " + productosBD.size());
        return productosBD.size(); 
    }
    
    // Getters y Setters 
    public static HashMap<String, Producto> getProductosBD() {
        return productosBD;
    }

    public static void setProductosBD(HashMap<String, Producto> productosBD) {
        ProductoCrud.productosBD = productosBD;
    }
    
    
}

