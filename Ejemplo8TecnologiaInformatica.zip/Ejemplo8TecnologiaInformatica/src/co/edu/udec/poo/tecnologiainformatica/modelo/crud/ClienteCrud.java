package co.edu.udec.poo.tecnologiainformatica.modelo.crud;

import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.Cliente;
import java.io.Serializable;
import java.util.*;


public class ClienteCrud implements Serializable {
    
    public ClienteCrud() {
        
    }
    
    // Creamos un HashMap con objetos de tipo Cliente. 
    private static HashMap<String, Cliente> clientesBD; 
    
    //Metodos CRUD. 
    public void agregar(Cliente cliente) {
        try { 
            if (clientesBD == null) {
                clientesBD = new HashMap<>();
            }
            clientesBD.put(cliente.getIdCliente(), cliente);
            System.out.println("Cliente guardado con exito! \n");
            
        }catch (Exception ex) {
            if (clientesBD.containsKey(cliente.getIdCliente())) {
                System.out.println("El cliente ya fue registrado!\n");
            }
        }
    }
    
    public void buscar(String codigoCliente) {
        if (clientesBD == null || clientesBD.isEmpty()){
            System.out.println("No existen Clientes registrados en la BD.\n");    
        }
        
        try {
            if (clientesBD.containsKey(codigoCliente)) {
                System.out.println("Los datos del cliente buscado son: ");
                System.out.println("idCliente: "+ clientesBD.get(codigoCliente).getIdCliente());
                System.out.println("Nombre: " + clientesBD.get(codigoCliente).getNombreCliente());
                System.out.println("DNI: " + clientesBD.get(codigoCliente).getDniCliente());
                System.out.println("Dirección: " + clientesBD.get(codigoCliente).getDireccionCliente());
                System.out.println("Fecha Compra: "+ clientesBD.get(codigoCliente).getFechaCompra());
                System.out.println("Numero de impresoras: " + clientesBD.get(codigoCliente).getNumProductos());
            }
            
            else {
                System.out.println("El cliente no existe en la BD!\n");
            }
        }catch(Exception ex) {
            System.out.println("Se encontró un error al guardar el cliente...");
        }
    }
    
    public void editar(Cliente c) {
        try{
            // Tomamos los del cliente nuevo.  
            String idCliente = c.getIdCliente();
            String nombreCliente = c.getNombreCliente(); 
            String DNI = c.getDniCliente();
            String telefono = c.getTelefonoCliente();
            String direccion = c.getDireccionCliente();
            String fechaCompra = c.getFechaCompra(); 
            int numImpresoras = c.getNumProductos(); 
            
            // Verificamos que este en el diccionario. 
            if (clientesBD.containsKey(idCliente)) {
                //Pasamos los nuevos datos. 
                Cliente cNuevo = clientesBD.get(idCliente);
                cNuevo.setIdCliente(idCliente);
                cNuevo.setNombreCliente(nombreCliente);
                cNuevo.setDniCliente(DNI);
                cNuevo.setTelefonoCliente(telefono);
                cNuevo.setDireccionCliente(direccion);
                cNuevo.setFechaCompra(fechaCompra);
                cNuevo.setNumProductos(numImpresoras);
                System.out.println("El cliente ha sido editado con exito!\n");
            }
            
            else {
                System.out.println("El cliente no se encontró en la BD!\n");
            }
            
        } catch (Exception ex) {
            System.out.println("Se encontró un error al editar el cliente...");
        }  
    }
    
    public void eliminar(String codigoCliente) {
        try {
            if (clientesBD.containsKey(codigoCliente)) {
                clientesBD.remove(codigoCliente); 
                System.out.println("Cliente eiminado con exito!\n");
            }
            
            else {
                System.out.println("El cliente no fue encontrado en la BD!");
            }
        } catch(Exception ex){
            System.out.println("Se encontró un error al eliminar el cliente");
        }
    }
    
    public void listarTodo() {
        // Recorremos el HashMap
        try{
            for (Cliente cliente: clientesBD.values()){
                System.out.println("\n\t.:Listado de proveedores:.");
                System.out.println("Id: " + cliente.getIdCliente());
                System.out.println("Nombre: " + cliente.getNombreCliente());
                System.out.println("DNI: " + cliente.getDniCliente());
                System.out.println("Fecha Compra: " + cliente.getFechaCompra());
                System.out.println("Telefono: " + cliente.getTelefonoCliente());
                System.out.println("Numero de impresoras: " + cliente.getNumProductos());
                System.out.println("");
            }
        } catch(Exception ex) {
            if ( clientesBD == null || clientesBD.isEmpty()) {
                System.out.println("No hay clientes registrados en la BD!");
            }
        }
    }
    
    public Integer contar() {
        System.out.println("\nEl numero de clientes registrados es de: " + clientesBD.size());
        return clientesBD.size(); 
    }
    
    // Getters y Setters. 
    public static HashMap<String, Cliente> getClientesBD() {
        return clientesBD;
    }

    public static void setClientesBD(HashMap<String, Cliente> clientesBD) {
        ClienteCrud.clientesBD = clientesBD;
    }
    
}
