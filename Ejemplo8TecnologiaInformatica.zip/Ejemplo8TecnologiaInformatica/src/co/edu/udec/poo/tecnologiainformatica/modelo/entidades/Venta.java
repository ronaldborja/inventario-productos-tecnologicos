package co.edu.udec.poo.tecnologiainformatica.modelo.entidades;

import java.io.Serializable;
import java.util.*;

public class Venta implements Serializable  {
    private String idVenta;
    private String fechaVenta; 
    private int numProductosVendidos; 
    private String productoVendido;
    private double totalFacturado; 
    
    // Ref a obj. 
    private Producto producto;
    
    public Venta() {
        
    }

    public Venta(String idVenta, String fechaVenta, int numProductosVendidos, Producto producto) {
        this.idVenta = idVenta;
        this.fechaVenta = fechaVenta;
        this.numProductosVendidos = numProductosVendidos;
        this.producto = producto;
    }
    
    // Getters & Setters. 
    public String getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(String idVenta) {
        this.idVenta = idVenta;
    }

    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public int getNumProductosVendidos() {
        return numProductosVendidos;
    }

    public void setNumProductosVendidos(int numProductosVendidos) {
        this.numProductosVendidos = numProductosVendidos;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public String getProductoVendido() {
        return productoVendido;
    }

    public void setProductoVendido(String productoVendido) {
        this.productoVendido = productoVendido;
    }

    public double getTotalFacturado() {
        return totalFacturado;
    }

    public void setTotalFacturado(double totalFacturado) {
        this.totalFacturado = totalFacturado;
    }
    
    
    
}
