package co.edu.udec.poo.tecnologiainformatica.modelo.entidades;

import java.io.Serializable;
import java.util.*;

public class Producto implements Serializable  {
    // Atributos del producto. 
    private String codigoProducto; 
    private String modeloProducto; 
    private String nombreProducto; 
    private double precioProducto; 
    private int cantidadDisponible; 
    private String masInformacion;
    private double precioServicioTecnico; 
    
    // Atributos no obligatorios (Solo para productos Alta Tecnologia)
    private String nombreEmpresaFabricante;
    private int numEmpleados; 
    private String paisOrigen; 
    private String fechaFabricacion;
    private boolean productoAT; 
    
    // Atributos tipo ref a objetos. 
    Cliente cliente; 
    EmpresaFabricante empresaFabricante; 
    ArrayList<Proveedor> listaProveedores;
    
    // Constructores. 
    public Producto(){
        
    }
    
    
    // Para impresoras --> Unico producto el que la empresa brinda servicio Técnico. 
    public Producto(String codigoProducto, String modeloProducto, String nombreProducto, double precioProducto, int cantidadDisponible, String masInformacion, double precioServicioTecnico) {
        this.codigoProducto = codigoProducto;
        this.modeloProducto = modeloProducto;
        this.nombreProducto = nombreProducto;
        this.precioProducto = precioProducto;
        this.cantidadDisponible = cantidadDisponible;
        this.masInformacion = masInformacion;
        this.precioServicioTecnico = precioServicioTecnico;
    }
    
    public Producto(String codigoProducto, String modeloProducto, String nombreProducto, double precioProducto, int cantidadDisponible, String masInformacion) {
        this.codigoProducto = codigoProducto;
        this.modeloProducto = modeloProducto;
        this.nombreProducto = nombreProducto;
        this.precioProducto = precioProducto;
        this.cantidadDisponible = cantidadDisponible;
        this.masInformacion = masInformacion;
    }

    // Constructor para productoAltaTecnología. 
    public Producto(String codigoProducto, String modeloProducto, String nombreProducto, double precioProducto, int cantidadDisponible, String masInformacion, double precioServicioTecnico, String paisOrigen, String fechaFabricacion, EmpresaFabricante empresaFabricante) {
        this.codigoProducto = codigoProducto;
        this.modeloProducto = modeloProducto;
        this.nombreProducto = nombreProducto;
        this.precioProducto = precioProducto;
        this.cantidadDisponible = cantidadDisponible;
        this.masInformacion = masInformacion;
        this.precioServicioTecnico = precioServicioTecnico;
        this.paisOrigen = paisOrigen;
        this.fechaFabricacion = fechaFabricacion;
        this.empresaFabricante = empresaFabricante;
    }
    
    
    // Constructor para producto Alta Tecnología sin meter el Servicio Técnico.  
    public Producto(String codigoProducto, String modeloProducto, String nombreProducto, double precioProducto, int cantidadDisponible, String masInformacion, String paisOrigen, String fechaFabricacion, EmpresaFabricante empresaFabricante) {
        this.codigoProducto = codigoProducto;
        this.modeloProducto = modeloProducto;
        this.nombreProducto = nombreProducto;
        this.precioProducto = precioProducto;
        this.cantidadDisponible = cantidadDisponible;
        this.masInformacion = masInformacion;
        this.paisOrigen = paisOrigen;
        this.fechaFabricacion = fechaFabricacion;
        this.empresaFabricante = empresaFabricante;
    }
    
    //Getters & Setters. 

    public String getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(String codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public String getModeloProducto() {
        return modeloProducto;
    }

    public void setModeloProducto(String modeloProducto) {
        this.modeloProducto = modeloProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public double getPrecioProducto() {
        return precioProducto;
    }

    public void setPrecioProducto(double precioProducto) {
        this.precioProducto = precioProducto;
    }

    public int getCantidadDisponible() {
        return cantidadDisponible;
    }

    public void setCantidadDisponible(int cantidadDisponible) {
        this.cantidadDisponible = cantidadDisponible;
    }

    public String getMasInformacion() {
        return masInformacion;
    }

    public void setMasInformacion(String masInformacion) {
        this.masInformacion = masInformacion;
    }

    public double getPrecioServicioTecnico() {
        return precioServicioTecnico;
    }

    public void setPrecioServicioTecnico(double precioServicioTecnico) {
        this.precioServicioTecnico = precioServicioTecnico;
    }

    public String getPaisOrigen() {
        return paisOrigen;
    }

    public void setPaisOrigen(String paisOrigen) {
        this.paisOrigen = paisOrigen;
    }

    public String getFechaFabricacion() {
        return fechaFabricacion;
    }

    public void setFechaFabricacion(String fechaFabricacion) {
        this.fechaFabricacion = fechaFabricacion;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public EmpresaFabricante getEmpresaFabricante() {
        return empresaFabricante;
    }

    public void setEmpresaFabricante(EmpresaFabricante empresaFabricante) {
        this.empresaFabricante = empresaFabricante;
    }

    public ArrayList<Proveedor> getListaProveedores() {
        return listaProveedores;
    }

    public void setListaProveedores(ArrayList<Proveedor> listaProveedores) {
        this.listaProveedores = listaProveedores;
    }

    public String getNombreEmpresaFabricante() {
        return nombreEmpresaFabricante;
    }

    public void setNombreEmpresaFabricante(String nombreEmpresaFabricante) {
        this.nombreEmpresaFabricante = nombreEmpresaFabricante;
    }

    public int getNumEmpleados() {
        return numEmpleados;
    }

    public void setNumEmpleados(int numEmpleados) {
        this.numEmpleados = numEmpleados;
    }

    public boolean isProductoAT() {
        return productoAT;
    }

    public void setProductoAT(boolean productoAT) {
        this.productoAT = productoAT;
    }
    
}
