package co.edu.udec.poo.tecnologiainformatica.modelo.crud;

import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.EmpresaFabricante;
import java.io.Serializable;
import java.util.*;


public class EmpresaFabricanteCrud implements Serializable {
    
    //Creamos un HashMap con objetos de tipo EmpresaFabricante. 
    private static HashMap<String, EmpresaFabricante> empresasFabricanteBD;
    
    public EmpresaFabricanteCrud(){
        
    }
    // Métodos CRUD. 
    
    // Método agregar. 
    public void agregar(EmpresaFabricante em) {
        try {
            if (empresasFabricanteBD == null) {
            empresasFabricanteBD = new HashMap<>();
            }
            empresasFabricanteBD.put(em.getIdEmpresa(), em);
            System.out.println("Empresa fabricante guardada con exito! ");
            
        }catch (Exception ex) {
            if (empresasFabricanteBD.containsKey(em.getIdEmpresa())) {
                System.out.println("La empresa ya está registrado!");
            }
        }
    }
    
    // Método buscar. 
    public void buscar(String idEmpresa) { 
        if (empresasFabricanteBD == null || empresasFabricanteBD.isEmpty()){
            System.out.println("No existen empresas registradas en la BD.\n");    
        }
        
        try {
            if (empresasFabricanteBD.containsKey(idEmpresa)) {
                System.out.println("Los datos del buscado producto son: ");
                System.out.println("IdEmpresa: "+ empresasFabricanteBD.get(idEmpresa).getIdEmpresa());
                System.out.println("Nombre: : " + empresasFabricanteBD.get(idEmpresa).getNombreEmpresa());
                System.out.println("Dirección: "+ empresasFabricanteBD.get(idEmpresa).getDireccionEmpresa());
                System.out.println("Numero Empleados: " + empresasFabricanteBD.get(idEmpresa).getDireccionEmpresa());
                System.out.println("Precio Soporte Tecnico: : " + empresasFabricanteBD.get(idEmpresa).getPrecioSoporteTecnico());
                
            } 
            
            else{
               System.out.println("La empresa no se encontró en la BD!"); 
            }
            
        } catch(Exception ex) {
                System.out.println("Se encontró un error consultar la empresa...");
        }
    }
    
    // Metodo editar. 
    public void editar(EmpresaFabricante em) {
        try{
            // Tomamos los del producto nuevo.  
            String idEmpresa = em.getIdEmpresa();
            String nombreEmpresa = em.getNombreEmpresa();
            String direccionEmpresa = em.getDireccionEmpresa(); 
            int numEmpleados = em.getNumEmpleados(); 
            double precioST = em.getPrecioSoporteTecnico();
            ArrayList productosAT = em.getProductosAT();
            
            // Verificamos que este en el diccionario. 
            if (empresasFabricanteBD.containsKey(idEmpresa)) {
                //Pasamos los nuevos datos. 
                EmpresaFabricante emNueva = empresasFabricanteBD.get(idEmpresa);
                emNueva.setNombreEmpresa(nombreEmpresa);
                emNueva.setDireccionEmpresa(direccionEmpresa);
                emNueva.setNumEmpleados(numEmpleados);
                emNueva.setPrecioSoporteTecnico(precioST);
                emNueva.setProductosAT(productosAT);                
                System.out.println("La empresa fabricante ha sido editada con exito!\n");
            }
            
            else {
                System.out.println("La empresa fabricante no se encontró en la BD!\n");
            }
            
        } catch (Exception ex) {
            System.out.println("Se encontró un error al editar la Empresa Fabricante...\n");
        }  
    }
    
    // Método eliminar. 
    public void eliminar(String idEmpresa) {
        try {
            if (empresasFabricanteBD.containsKey(idEmpresa)) {
                empresasFabricanteBD.remove(idEmpresa); 
                System.out.println("Empresa fabricante eliminada con exito!\n");
            }
            else {
                System.out.println("La empresa fabricante no fue encontrado en la BD!");
            }
        } catch(Exception ex){
            System.out.println("Se encontró un error al eliminar la empresa...");
        }
    }
    
    public void listarTodo() {
        // Recorremos el HashMap
        try{
            System.out.println("\n\t.:Listado de empresas fabricantes:");
            for (EmpresaFabricante em: empresasFabricanteBD.values()){
                System.out.println("IdEmpresa: " + em.getIdEmpresa());
                System.out.println("Nombre Empresa: " + em.getNombreEmpresa());
                System.out.println("Dirección: " + em.getDireccionEmpresa());
                System.out.println("Numero Empleados: " + em.getNumEmpleados());
                System.out.println("Precio Soporte Técnico: " + em.getPrecioSoporteTecnico());
                System.out.println("");
            }
        } catch(Exception ex) {
            if (empresasFabricanteBD == null || empresasFabricanteBD.isEmpty()) {
                System.out.println("No hay empresas registradas en la BD!");
            }
        }
    }
    
        
    public Integer contar() {
        System.out.println("\nEl numero de empresas fabricantes registradas es de: " + empresasFabricanteBD.size());
        return empresasFabricanteBD.size(); 
    }
    
    // Getters y Setters. 

    public static HashMap<String, EmpresaFabricante> getEmpresasFabricanteBD() {
        return empresasFabricanteBD;
    }

    public static void setEmpresasFabricanteBD(HashMap<String, EmpresaFabricante> empresasFabricanteBD) {
        EmpresaFabricanteCrud.empresasFabricanteBD = empresasFabricanteBD;
    }
    
}


