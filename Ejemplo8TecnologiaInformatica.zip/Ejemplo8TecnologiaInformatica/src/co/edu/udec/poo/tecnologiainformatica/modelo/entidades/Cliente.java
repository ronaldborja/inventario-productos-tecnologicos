package co.edu.udec.poo.tecnologiainformatica.modelo.entidades;

import java.io.Serializable;
import java.util.*;

public class Cliente implements Serializable {
    
    // Atributos básicos. 
    private String idCliente; 
    private String nombreCliente; 
    private String dniCliente; 
    private String telefonoCliente; 
    private String direccionCliente; 
    private String fechaCompra; 
    private Integer numProductos; 
    private double totalFacturado; 
    
    // Atributos tipo ref a objetos. 
    private ArrayList<Producto> listaProductosCliente;
    
    // Constructores.
    public Cliente() {
        
    }

    public Cliente(String idCliente, String nombreCliente, String dniCliente, String telefonoCliente, String direccionCliente, String fechaCompra, Integer numProductos) {
        this.idCliente = idCliente;
        this.nombreCliente = nombreCliente;
        this.dniCliente = dniCliente;
        this.telefonoCliente = telefonoCliente;
        this.direccionCliente = direccionCliente;
        this.fechaCompra = fechaCompra;
        this.numProductos = numProductos;
    }
    
    // Getters & Setters. 

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getDniCliente() {
        return dniCliente;
    }

    public void setDniCliente(String dniCliente) {
        this.dniCliente = dniCliente;
    }

    public String getDireccionCliente() {
        return direccionCliente;
    }

    public void setDireccionCliente(String direccionCliente) {
        this.direccionCliente = direccionCliente;
    }

    public String getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(String fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public Integer getNumProductos() {
        return numProductos;
    }

    public void setNumProductos(Integer numProductos) {
        this.numProductos = numProductos;
    }

    public ArrayList<Producto> getListaProductosCliente() {
        return listaProductosCliente;
    }

    public void setListaProductosCliente(ArrayList<Producto> listaProductosCliente) {
        this.listaProductosCliente = listaProductosCliente;
    }

    public String getTelefonoCliente() {
        return telefonoCliente;
    }

    public void setTelefonoCliente(String telefonoCliente) {
        this.telefonoCliente = telefonoCliente;
    }

    public double getTotalFacturado() {
        return totalFacturado;
    }

    public void setTotalFacturado(double totalFacturado) {
        this.totalFacturado = totalFacturado;
    }
    
    
}
