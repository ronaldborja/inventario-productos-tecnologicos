package co.edu.udec.poo.tecnologiainformatica.modelo.entidades;

import java.io.Serializable;

public class Admin implements Serializable {
    
    private String nombreUsuario = "admin"; 
    private String claveUsuario = "admin"; 
    
    public Admin() {
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getClaveUsuario() {
        return claveUsuario;
    }

    public void setClaveUsuario(String claveUsuario) {
        this.claveUsuario = claveUsuario;
    }
}
