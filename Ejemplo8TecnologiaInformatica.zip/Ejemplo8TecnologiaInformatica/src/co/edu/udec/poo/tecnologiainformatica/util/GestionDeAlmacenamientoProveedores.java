package co.edu.udec.poo.tecnologiainformatica.util;

import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.Producto;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GestionDeAlmacenamientoProveedores {
    
    public static String rutaBD;
    
    // Métodos para guardar y recuperar los diccionarios de cada clase. 
    
    public static void obtenerRuta() {
        String rutaUsuario = System.getProperty("user.home"); 
        rutaBD = rutaUsuario + File.separator + "proveedoresBD.dat"; 
    }
    
    //Guardar Objetos de claseProducto. 
    public static void guardarEnArchivo(Object datos) throws Exception {
        try {
            //Flujo de datos al entorno. 
            FileOutputStream flujoSalidaDatos = new FileOutputStream(rutaBD);
            //Convertir el flujo de salida a objeto y lo guardamos
            ObjectOutputStream salidaObjeto = new ObjectOutputStream(flujoSalidaDatos); 
            salidaObjeto.writeObject(datos);
            
        } catch (FileNotFoundException ex) {
            throw new Exception("SE ENCONTRÓ UN ERROR AL CREAR LA BASE DE DATOS" + ex.getMessage()); 
        }
    }
    
    //Nota: Objetos serializables --> Convertir los objetos en unos y ceros y luego puedan ser recuperados. 
    // implements Serializable. 
    
    public static Object recuperarArchivo() throws Exception {
        //Obtenemos la ruta: 
        obtenerRuta(); 
        
        try {
            //Crear el flujo de entrada al programa.
            FileInputStream flujoEntradaDatos = new FileInputStream(rutaBD);
            //Convertir el flujo a objeto y leerlos. 
            ObjectInputStream entradaObjeto = new ObjectInputStream(flujoEntradaDatos); 
            Object datos = entradaObjeto.readObject();
            return datos; 
            
        } catch (FileNotFoundException ex) {
           throw new Exception("ERROR AL LEER LOS DATOS" + ex.getMessage());   
        }
    }
}
