package co.edu.udec.poo.tecnologiainformatica;

import co.edu.udec.poo.tecnologiainformatica.modelo.crud.AlquilerCrud;
import co.edu.udec.poo.tecnologiainformatica.modelo.crud.ClienteCrud;
import co.edu.udec.poo.tecnologiainformatica.modelo.crud.EmpresaFabricanteCrud;
import co.edu.udec.poo.tecnologiainformatica.modelo.crud.ProductoCrud;
import co.edu.udec.poo.tecnologiainformatica.modelo.crud.ProveedorCrud;
import co.edu.udec.poo.tecnologiainformatica.modelo.crud.VentaCrud;
import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.EmpresaFabricante;
import co.edu.udec.poo.tecnologiainformatica.modelo.entidades.Proveedor;
import co.edu.udec.poo.tecnologiainformatica.vistas.gui.VentanaPrincipal;
import java.util.*;

/**
 *
 * @Autores: Ronald Borja &  Marylin Torres.
 */

public class Principal {
    
    public static void main(String[] args) {
        // Entrega #3: Diseñar una GUI para controlar el sistema. 
        // CODIGO PARA EJECUTAR LA GUI. 
        
        // Creamos un objeto y lo guardamos en ventana. 
        VentanaPrincipal ventana = new VentanaPrincipal();
        ventana.setLocationRelativeTo(null); //Colocarla en el centro
        ventana.setExtendedState(VentanaPrincipal.MAXIMIZED_BOTH);
        ventana.setVisible(true);  //Hacer que sea visible. 
        
  }
}   
